const RMItems = [
  {
    title: "All reviews",
    count: 10.4,
  },
  {
    title: "Facebook",
    count: 4.5,
  },
  {
    title: "Trip Advisor",
    count: 5.3,
  },
  {
    title: "Google",
    count: 6.9,
  },
];

export default RMItems;
