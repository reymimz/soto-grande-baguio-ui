const BuildingList = [
  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic12_bhsguy.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic4_pdc8nm.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic1_yuyqvx.png",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic6_pgsidz.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic5_pyomc1.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626227/sgbh_colection/pic1_kn6qth.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic1_yuyqvx.png",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic5_pyomc1.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665625676/sgbh_colection/main_yoxbfy.jpg",
];

const RoomList = [
  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic12_bhsguy.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic4_pdc8nm.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic1_yuyqvx.png",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic6_pgsidz.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic5_pyomc1.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626227/sgbh_colection/pic1_kn6qth.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic1_yuyqvx.png",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic5_pyomc1.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665625676/sgbh_colection/main_yoxbfy.jpg",
];

const PoolList = [
  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic12_bhsguy.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic4_pdc8nm.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic1_yuyqvx.png",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic6_pgsidz.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic5_pyomc1.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626227/sgbh_colection/pic1_kn6qth.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic1_yuyqvx.png",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626267/sgbh_colection/pic5_pyomc1.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665626268/sgbh_colection/pic7_xywkjq.jpg",

  "https://res.cloudinary.com/dkbbweo5x/image/upload/v1665625676/sgbh_colection/main_yoxbfy.jpg",
];

export { BuildingList, RoomList, PoolList };


