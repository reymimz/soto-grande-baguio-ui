import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import ChairOutlinedIcon from "@mui/icons-material/ChairOutlined";
import PaymentsOutlinedIcon from "@mui/icons-material/PaymentsOutlined";
import ApartmentOutlinedIcon from "@mui/icons-material/ApartmentOutlined";
import CollectionsOutlinedIcon from "@mui/icons-material/CollectionsOutlined";
import ReviewsOutlinedIcon from "@mui/icons-material/ReviewsOutlined";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import ForwardToInboxOutlinedIcon from "@mui/icons-material/ForwardToInboxOutlined";

const MenuItems = [
  {
    title: "Home",
    path: "/home",
    icon: <HomeOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
  {
    title: "Rooms",
    path: "/rooms",
    icon: <ChairOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
  {
    title: "Reservation",
    path: "/rooms",
    icon: <PaymentsOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
  {
    title: "Facilities",
    path: "/facilities",
    icon: <ApartmentOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
  {
    title: "Gallery",
    path: "/gallery",
    icon: <CollectionsOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
  {
    title: "Reviews",
    path: "/reviews",
    icon: <ReviewsOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
  {
    title: "Location",
    path: "/location",
    icon: <LocationOnOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
  {
    title: "Contact",
    path: "/contact",
    icon: <ForwardToInboxOutlinedIcon className="cn-ic" />,
    cName: "nav-text",
  },
];

export default MenuItems;
