import React from "react";
import CButton from "../buttons/CButton";

const TextArea = () => {
  return (
    <>
      <textarea style={{ outline: "none" }} rows="4" cols="50"></textarea>
      <CButton bName="book-wrapper " label="SUBMIT" />
    </>
  );
};

export default TextArea;
