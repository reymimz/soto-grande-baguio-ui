import React from "react";
import "./ccard.scss";
import Rating from "@mui/material/Rating";

const Ccard = (props) => {
  const { name, star, time, content, icon } = props;
  return (
    <>
      <div className="c-card">
        <div className="c-top">
          <img src={icon} alt="Profile" className="c-pro" />
          <div className="c-name">
            <span className="name">{name}</span>
            <Rating name="read-only" value={star} readOnly className="c-star" />
            <span className="time">{time}</span>
          </div>
        </div>
        <div className="c-bottom">
          <p className="cc-content">{content}</p>
        </div>
      </div>
    </>
  );
};

export default Ccard;
