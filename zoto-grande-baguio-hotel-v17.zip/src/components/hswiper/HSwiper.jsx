import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/autoplay";
import { BuildingList, PoolList, RoomList } from "../../contexts/ImageList";
import "./hswiper.scss";

const HSwiper = ({ data }) => {
  return (
    <>
      <Swiper
        modules={[Autoplay]}
        style={{ marginBottom: "1rem" }}
        className="mySwiper"
        autoplay={{ delay: 2000 }}
      >
        {PoolList.map((item, i) => {
          return (
            <SwiperSlide className="sw-wrapper" key={i}>
              <img src={item} alt="slider" className="sw-img" />
            </SwiperSlide>
          );
        })}
      </Swiper>
    </>
  );
};

export default HSwiper;
