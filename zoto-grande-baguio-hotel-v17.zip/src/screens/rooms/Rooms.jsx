import React from "react";
import Booking from "../booking/Booking";
import "./rooms.scss";
import LineHeader from "../../components/lineheader/LineHeader";
import HSwiper from "../../components/hswiper/HSwiper";
import CFooter from "../../components/cfooter/CFooter";

const Rooms = () => {
  return (
    <>
      <div className="rooms">
        <HSwiper />
        <LineHeader title="Reservation" />
        <Booking />
        <Booking />
        <Booking />
        <Booking />
      </div>
      <CFooter />
    </>
  );
};

export default Rooms;
