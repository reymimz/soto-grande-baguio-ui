import React from "react";
import "./gallery.scss";
import CFooter from "../../components/cfooter/CFooter";
import SmallHeader from "../../components/smallheader/SmallHeader";
import RSwiper from "../../components/rswipper/RSwiper";
import { BuildingList, PoolList, RoomList } from "../../contexts/ImageList";

const Gallery = () => {
  return (
    <>
      <div className="gallery">
        <SmallHeader
          title="Soto Grande Baguio Hotel - Gallery"
          cTitle="sh-title2"
        />
        <div className="g-container">
          <RSwiper data={BuildingList} title="Discover Building" />
          <RSwiper data={RoomList} title="Discover Rooms" />
          <RSwiper data={PoolList} title="Discover Swimming Pool" />
          <RSwiper data={PoolList} title="Discover Aminities" />
        </div>
      </div>
      <CFooter />
    </>
  );
};

export default Gallery;
