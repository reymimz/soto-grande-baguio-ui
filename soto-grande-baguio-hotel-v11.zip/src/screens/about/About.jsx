import React from "react";
import CAbout from "../../components/cabout/CAbout";
import "./about.scss";
import CFooter from "../../components/cfooter/CFooter";

const About = () => {
  return (
    <>
      <div className="about-wrapper">
        <div className="a-main">
          <CAbout className="h-info-wrapper" />
        </div>
      </div>
    </>
  );
};

export default About;
