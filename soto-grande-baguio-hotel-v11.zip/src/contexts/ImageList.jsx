const ImageList = [
  "https://i.ibb.co/9nD5LKx/pic1.jpg",
  "https://i.ibb.co/RQyyDyS/pic3.jpg",
  "https://i.ibb.co/0yTP902/pic4.jpg",
  "https://i.ibb.co/NKgCD87/pic5.jpg",
  "https://i.ibb.co/Cz3FVkY/pic7.jpg",
  "https://i.ibb.co/PNdVHxC/pic8.jpg",
  "https://i.ibb.co/10HkJtd/pic9.jpg",
  "https://i.ibb.co/vzdWj5d/pic10.jpg",
  "https://i.ibb.co/XxZhYCk/pic13.jpg",
  "https://i.ibb.co/zQJzkZk/pic11.jpg",
  "https://i.ibb.co/HC574VC/pic12.jpg",
  "https://i.ibb.co/10HkJtd/pic9.jpg",
  "https://i.ibb.co/vzdWj5d/pic10.jpg",
  "https://i.ibb.co/XxZhYCk/pic13.jpg",
  "https://i.ibb.co/zQJzkZk/pic11.jpg",
];

export default ImageList;
