import DropDown from "../components/dropDown/DropDown";
import * as AiIcons from 'react-icons/ai';


const MenuItems = [
  {
    title: "HOME",
    path: "/home",
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  {
    title: <DropDown />,
  },
  {
    title: "GALLERY",
    path: "/gallery",
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  {
    title: "REVIEWS",
    path: "/reviews",
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  {
    title: "LOCATION",
    path: "/location",
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  {
    title: "ABOUT",
    path: "/about",
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
];

export default MenuItems;
