const RData = [
  {
    icon: "https://via.placeholder.com/150/24f355",
    name: "Reynaldo C. Mimis",
    star: "3",
    time: "1 month ago",
    content: "Nice place live not so crowded and private part of QC",
  },
  {
    icon: "https://via.placeholder.com/150/f66b97",
    name: "Fortune Bitos",
    star: "4",
    time: "3 months ago",
    content:
      "The rooms are very clean and linen and beddings are fresh.Shower rooms are fresh.",
  },
  {
    icon: "https://via.placeholder.com/150/d32776",
    name: "Chriz Bobis",
    star: "5",
    time: "4 months ago",
    content: "Neat and clean room with courteous staff.",
  },
  {
    icon: "https://via.placeholder.com/150/24f355",
    name: "Patrick Pogi",
    star: "4",
    time: "2 months ago",
    content:
      "Super nice staff! The bathroom is a little dated and could use an update but overall, the stay was",
  },
  {
    icon: "https://via.placeholder.com/150/d32776",
    name: "Chriz Ng Bayan",
    star: "3",
    time: "1 month ago",
    content: "Very secure and accommodating",
  },
  {
    icon: "https://via.placeholder.com/150/24f355",
    name: "Jasuon Pogi",
    star: "4",
    time: "2 months ago",
    content: "dami chicks",
  },
  {
    icon: "https://via.placeholder.com/150/d32776",
    name: "Chriz Bobis",
    star: "5",
    time: "4 months ago",
    content: "Neat and clean room with courteous staff.",
  },
  {
    icon: "https://via.placeholder.com/150/24f355",
    name: "Patrick Pogi",
    star: "4",
    time: "2 months ago",
    content:
      "Super nice staff! The bathroom is a little dated and could use an update but overall, the stay was",
  },
  {
    icon: "https://via.placeholder.com/150/d32776",
    name: "Chriz Ng Bayan",
    star: "3",
    time: "1 month ago",
    content: "Very secure and accommodating",
  },
  {
    icon: "https://via.placeholder.com/150/24f355",
    name: "Jasuon Pogi",
    star: "4",
    time: "2 months ago",
    content: "dami chicks",
  },
  {
    icon: "https://via.placeholder.com/150/24f355",
    name: "Jasuon Pogi",
    star: "4",
    time: "2 months ago",
    content: "dami chicks",
  },
];

export default RData;
